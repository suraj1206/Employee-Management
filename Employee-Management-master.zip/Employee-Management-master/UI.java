
public class UI {
    public void option(){
        System.out.println("Press keys to perform...........");
        System.out.println("\t1. Add New Employee");
        System.out.println("\t2. Employee's Salary");
        System.out.println("\t3. Increase Individual Salary");
        System.out.println("\t4. Employee's Info");
        System.out.println("\t5. List of Employees");
        System.out.println("\t0. Exit");
    }
    public void subEmployeeOption(){
        System.out.println("\t\tSelect employee type..........");
        System.out.println("\t\t1. Salaried Employee");
        System.out.println("\t\t2. Hourly Employee");
        System.out.println("\t\t3. Commission Employee");
    }
}